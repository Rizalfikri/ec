<!DOCTYPE html>
<html lang="en">
    <?php echo $header; ?>
<!--================End Menu Area =================-->
    
    
<!--================Footer Area =================-->   
<?php echo $footer; ?>
</body>
</html>